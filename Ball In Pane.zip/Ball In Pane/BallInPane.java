import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;
import javafx.scene.text.*;
import javafx.scene.layout.Pane;
import javafx.scene.control.*;

public class BallInPane extends Pane{
	private Circle circle = new Circle (25, 25, 25);
	
	public BallInPane() {
		circle.setFill(Color.WHITE);
		circle.setStroke(Color.BLACK);
		getChildren().add(circle);
	}
	
	public void moveCircleUp() {
		circle.setCenterX(circle.getCenterX());
		circle.setCenterY(circle.getCenterY() > circle.getRadius() ? circle.getCenterY() - 25 : circle.getCenterY());
	}
	
	public void moveCircleDown() {
		circle.setCenterX(circle.getCenterX());
		circle.setCenterY(circle.getCenterY() < getHeight() - circle.getRadius() ? circle.getCenterY() + 25 : circle.getCenterY());
	}
	
	public void moveCircleLeft() {
		circle.setCenterX(circle.getCenterX() > circle.getRadius() ? circle.getCenterX() - 25 : circle.getCenterX());
		circle.setCenterY(circle.getCenterY());
	}
	
	public void moveCircleRight() {
		circle.setCenterX(circle.getCenterX() < getWidth() - circle.getRadius() ? circle.getCenterX() + 25 : circle.getCenterX());
		circle.setCenterY(circle.getCenterY());
	}
	
}