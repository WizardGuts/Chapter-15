import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;
import javafx.scene.text.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.*;
import javafx.geometry.Pos;
import javafx.geometry.*;
import javafx.scene.layout.HBox;
import javafx.scene.control.Button;

public class Exercise15_03 extends Application {
	private BallInPane ball = new BallInPane();
	@Override
	public void start(Stage primaryStage) {
		
		HBox hBox = new HBox();
		hBox.setAlignment(Pos.CENTER);
		hBox.setSpacing(10);
		Button btUp = new Button("Up");
		Button btDown = new Button("Down");
		Button btLeft = new Button("Left");
		Button btRight = new Button("Right");
			hBox.getChildren().add(btUp);
			hBox.getChildren().add(btDown);
			hBox.getChildren().add(btLeft);
			hBox.getChildren().add(btRight);
			
		btUp.setOnAction(e -> ball.moveCircleUp());
		btDown.setOnAction(e -> ball.moveCircleDown());
		btLeft.setOnAction(e -> ball.moveCircleLeft());
		btRight.setOnAction(e -> ball.moveCircleRight());
			
		
		BorderPane pane = new BorderPane();
		pane.setCenter(ball);
		pane.setBottom(hBox);
		
		Scene scene = new Scene(pane, 250, 250);
		primaryStage.setTitle("Ball in Pane");
		primaryStage.setScene(scene); 
		primaryStage.show();
	}
}